// <script>
// When the user clicks on <div>, open the popup
function myFunction() {
  var popup = document.getElementById("myPopup");
  popup.classList.toggle("show");
}
// </script>

function myFunction1() {
  var popup = document.getElementById("myPopup1");
  popup.classList.toggle("show");
}

function myFunction2() {
  var popup = document.getElementById("myPopup2");
  popup.classList.toggle("show");
}

function myFunction3() {
  var popup = document.getElementById("myPopup3");
  popup.classList.toggle("show");
}

function myFunction4() {
  var popup = document.getElementById("myPopup4");
  popup.classList.toggle("show");
}

function myFunction5() {
  var popup = document.getElementById("myPopup5");
  popup.classList.toggle("show");
}

function myFunction6() {
  var popup = document.getElementById("myPopup6");
  popup.classList.toggle("show");
}

function myFunction7() {
  var popup = document.getElementById("myPopup7");
  popup.classList.toggle("show");
}

function myFunction8() {
  var popup = document.getElementById("myPopup8");
  popup.classList.toggle("show");
}

function myFunction9() {
  var popup = document.getElementById("myPopup9");
  popup.classList.toggle("show");
}

function myFunction10() {
  var popup = document.getElementById("myPopup10");
  popup.classList.toggle("show");
}

function myFunction11() {
  var popup = document.getElementById("myPopup11");
  popup.classList.toggle("show");
}

function myFunction12() {
  var popup = document.getElementById("myPopup12");
  popup.classList.toggle("show");
}

function myFunction13() {
  var popup = document.getElementById("myPopup13");
  popup.classList.toggle("show");
}

function myFunction14() {
  var popup = document.getElementById("myPopup14");
  popup.classList.toggle("show");
}
